from cool_pipeline.pipelines import CustomETLPipeline

CustomETLPipeline().run()
